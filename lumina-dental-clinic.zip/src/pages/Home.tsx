import Hero from '../components/Hero';
import About from '../components/About';
import Services from '../components/Services';
import Features from '../components/Features';
import Doctor from '../components/Doctor';
import BlogPreview from '../components/BlogPreview';
import Testimonials from '../components/Testimonials';
import Appointment from '../components/Appointment';
import Contact from '../components/Contact';

export default function Home() {
  return (
    <>
      <Hero />
      <Features />
      <About />
      <Services preview={true} />
      <Doctor />
      <BlogPreview />
      <Testimonials />
      <Appointment />
      <Contact />
    </>
  );
}
