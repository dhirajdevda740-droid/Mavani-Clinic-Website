import { useEffect } from 'react';
import { ArrowLeft, Clock, Share2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import Appointment from '../components/Appointment';

export default function BlogPost() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24 min-h-screen bg-white pb-0">
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Link to="/" className="inline-flex items-center text-slate-500 hover:text-primary mb-8 transition-colors font-medium text-sm">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
        </Link>
        
        <div className="mb-8">
          <div className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold uppercase tracking-wider mb-4 border border-primary/20">
            Trending Topic
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-slate-900 mb-6 leading-tight">
            The Truth About the Viral "Turkey Teeth" Trend
          </h1>
          
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-sm text-slate-500 border-b border-slate-100 pb-8">
            <div className="flex items-center gap-3">
              <img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Dr. Sarah Mitchell" className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm" />
              <span className="font-semibold text-slate-900">Dr. Sarah Mitchell</span>
            </div>
            <div className="hidden sm:block w-1 h-1 rounded-full bg-slate-300"></div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> 5 min read
            </div>
            <div className="hidden sm:block w-1 h-1 rounded-full bg-slate-300"></div>
            <div>
              October 24, 2024
            </div>
            <button className="ml-auto flex items-center gap-2 text-slate-500 hover:text-primary transition-colors bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <Share2 className="w-4 h-4" /> Share
            </button>
          </div>
        </div>

        <div className="rounded-3xl overflow-hidden mb-12 h-[40vh] md:h-[60vh] relative shadow-xl">
          <img 
            src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80" 
            alt="Dental Veneers vs Crowns" 
            className="w-full h-full object-cover"
          />
        </div>

        <div className="prose prose-lg prose-slate max-w-none font-sans leading-relaxed text-slate-700">
          <p className="text-xl text-slate-600 mb-8 leading-relaxed">
            If you've scrolled through TikTok or Instagram recently, you've likely seen influencers flashing blindingly white, perfectly straight smiles achieved through "dental tourism," specifically in Turkey. But what many of these viral videos fail to explain is the severe, irreversible cost to their natural teeth.
          </p>

          <h2 className="text-2xl font-display font-bold text-slate-900 mt-10 mb-4">Veneers vs. Crowns: The Big Misunderstanding</h2>
          <p className="mb-6">
            In standard cosmetic dentistry, when a patient wants to improve the appearance of their smile, we usually opt for <strong>porcelain veneers</strong>. A veneer requires removing only a paper-thin layer of enamel (about 0.3mm to 0.5mm) from the front of the tooth. It's minimally invasive and preserves the tooth's structural integrity and nerve health.
          </p>
          <p className="mb-6">
            However, what many "Turkey Teeth" patients are actually receiving are <strong>full crowns</strong>. To place a crown, the dentist files the tooth down into tiny "pegs" (often removing up to 60-70% of the healthy tooth structure). This is an incredibly aggressive treatment normally reserved for teeth that are severely decayed, fractured, or have had a root canal. Doing this to healthy teeth purely for aesthetic reasons is highly controversial in the dental community.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-12">
            <img src="https://images.unsplash.com/photo-1598256989467-36e39265f617?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Dental setup" className="rounded-2xl shadow-md w-full h-64 object-cover" />
            <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Consultation" className="rounded-2xl shadow-md w-full h-64 object-cover object-top" />
          </div>

          <h2 className="text-2xl font-display font-bold text-slate-900 mt-10 mb-4">The Hidden Risks of Aggressive Filing</h2>
          <ul className="list-disc pl-6 mb-8 space-y-3">
            <li><strong>Nerve Damage:</strong> Filing away so much protective enamel and dentin traumatizes the tooth's nerve. Many patients require multiple root canals weeks or months after the procedure due to severe pain and infection.</li>
            <li><strong>Lifespan of Restorations:</strong> Crowns and veneers don't last forever. They typically need replacing every 10 to 15 years. If you get crowns at age 20, you'll need them replaced multiple times in your lifetime. Every replacement removes more tooth structure. Eventually, there won't be enough tooth left, leading to extractions and implants.</li>
            <li><strong>Gum Disease:</strong> Poorly fitted crowns with bulky margins trap plaque, leading to chronic gingivitis, bad breath, and eventual bone loss.</li>
          </ul>

          <blockquote className="border-l-4 border-primary bg-primary/5 pl-6 py-4 pr-4 rounded-r-xl my-10 italic text-2xl text-slate-800 font-display shadow-sm">
            "Your natural enamel is the most precious tissue your body produces—it doesn't grow back. True cosmetic dentistry enhances your smile while preserving what nature gave you."
          </blockquote>

          <h2 className="text-2xl font-display font-bold text-slate-900 mt-10 mb-4">What You Should Do Instead</h2>
          <p className="mb-6">
            If you're unhappy with your smile, there are numerous safe, conservative, and long-lasting options:
          </p>
          <ol className="list-decimal pl-6 mb-8 space-y-3 marker:text-primary font-medium">
            <li><strong className="text-slate-900">Clear Aligners:</strong> Straightening your natural teeth takes time but provides permanent, lifetime results without removing any enamel.</li>
            <li><strong className="text-slate-900">Professional Whitening:</strong> Modern whitening treatments can dramatically brighten your teeth without structural damage.</li>
            <li><strong className="text-slate-900">Composite Bonding:</strong> Using tooth-colored resin to fix chips, gaps, and shapes with zero enamel removal.</li>
            <li><strong className="text-slate-900">Porcelain Veneers:</strong> When done locally by a trusted specialist, true veneers offer the "Hollywood Smile" safely.</li>
          </ol>

          <p className="mb-6 border-t border-slate-100 pt-8 mt-12 bg-slate-50 p-6 rounded-2xl text-sm italic">
            Always consult a certified local specialist before making irreversible decisions about your health. The cheapest option today might end up costing you your natural teeth—and tens of thousands of dollars in restorative work—in the future.
          </p>
        </div>
      </article>

      <div className="mt-12 bg-background-soft">
        <Appointment />
      </div>
    </div>
  );
}
