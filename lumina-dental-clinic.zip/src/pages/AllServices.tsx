import { useEffect } from 'react';
import Services from '../components/Services';
import Appointment from '../components/Appointment';

export default function AllServices() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24 min-h-screen border-t border-slate-200">
      <Services preview={false} />
      <Appointment />
    </div>
  );
}
