export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-20 pb-10 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <a href="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white shadow-lg">
                <span className="font-display font-bold text-xl tracking-tighter">L</span>
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-lg leading-none text-white">LUMINA</span>
                <span className="text-[10px] uppercase tracking-widest text-primary font-medium font-sans">Dental Studio</span>
              </div>
            </a>
            <p className="text-sm text-slate-400 leading-relaxed mb-6">
              The city's premiere orthodontic and multi-speciality dental clinic. We craft confident smiles using state-of-the-art technology and a patient-first approach.
            </p>
            <div className="flex gap-4">
              {['Facebook', 'Instagram', 'Twitter'].map(social => (
                <a key={social} href="#" className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-primary hover:border-primary text-slate-400 hover:text-white transition-all">
                  <span className="text-xs font-semibold">{social[0]}</span>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6 font-display tracking-wide uppercase text-sm">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About Clinic', 'Our Doctor', 'Testimonials', 'Book Appointment'].map(link => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '-')}`} className="text-sm hover:text-primary transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6 font-display tracking-wide uppercase text-sm">Our Services</h4>
            <ul className="space-y-3">
              {['Braces Treatment', 'Invisible Aligners', 'Dental Implants', 'Root Canal', 'Smile Designing'].map(link => (
                <li key={link}>
                  <a href="#services" className="text-sm hover:text-primary transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-6 font-display tracking-wide uppercase text-sm">Newsletter</h4>
            <p className="text-sm text-slate-400 mb-4">Subscribe to receive smile care tips and offers.</p>
            <form className="flex border border-slate-800 rounded-lg overflow-hidden focus-within:border-primary transition-colors">
              <input type="email" placeholder="Your email..." className="w-full bg-slate-900 px-4 py-2 text-sm text-white focus:outline-none" />
              <button type="submit" className="bg-slate-800 hover:bg-primary px-4 text-sm font-medium transition-colors text-white">
                Join
              </button>
            </form>
          </div>

        </div>

        <div className="border-t border-slate-800/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-500">
            &copy; {new Date().getFullYear()} Lumina Dental Studio. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-slate-500">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
