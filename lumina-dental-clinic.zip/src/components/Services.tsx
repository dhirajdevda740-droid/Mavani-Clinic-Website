import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  Stethoscope, Smile, Activity, Sparkles, 
  Baby, Syringe, HeartPulse, Shield, LayoutGrid 
} from 'lucide-react';

export default function Services({ preview = false }: { preview?: boolean }) {
  const services = [
    {
      title: "Braces Treatment",
      description: "Traditional and advanced orthotic solutions for perfect teeth alignment.",
      icon: LayoutGrid // Replace with an appropriate icon or mapping later
    },
    {
      title: "Invisible Aligners",
      description: "Clear, removable aligners for a discreet straightening experience.",
      icon: Smile
    },
    {
      title: "Dental Implants",
      description: "Permanent, natural-looking replacements for missing teeth.",
      icon: Shield
    },
    {
      title: "Root Canal Treatment",
      description: "Painless procedures to save and restore infected or damaged teeth.",
      icon: Stethoscope
    },
    {
      title: "Teeth Whitening",
      description: "Professional whitening treatments for a brighter, more confident smile.",
      icon: Sparkles
    },
    {
      title: "Smile Designing",
      description: "Comprehensive aesthetic makeovers tailored to your facial structure.",
      icon: Smile
    },
    {
      title: "Kids Dentistry",
      description: "Gentle and specialized care to ensure healthy smiles for children.",
      icon: Baby
    },
    {
      title: "Cosmetic Dentistry",
      description: "Advanced cosmetic procedures including veneers and bonding.",
      icon: Sparkles
    },
    {
      title: "Crowns & Bridges",
      description: "Durable restorations to protect weak teeth and bridge gaps.",
      icon: Shield
    },
    {
      title: "Wisdom Tooth Removal",
      description: "Safe and comfortable extractions with quick recovery protocols.",
      icon: Syringe
    },
    {
      title: "Gum Treatment",
      description: "Periodontal care to maintain healthy gums and prevent diseases.",
      icon: HeartPulse
    },
    {
      title: "Full Mouth Rehab",
      description: "Complete restorative treatments for complex dental issues.",
      icon: Activity
    }
  ];

  const displayedServices = preview ? services.slice(0, 4) : services;

  return (
    <section id="services" className="py-24 bg-background-soft relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-primary font-semibold text-sm mb-4 border border-blue-100">
            Our Expertise
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-6">
            Comprehensive <span className="text-primary">Dental Care</span>
          </h2>
          <p className="text-lg text-slate-600">
            We offer a full spectrum of dental treatments, combining advanced technology with expert care to ensure your smile remains flawless.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {displayedServices.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              className="bg-white rounded-2xl p-6 card-shadow border border-slate-100 hover:border-primary/20 transition-all duration-300 group hover:-translate-y-1"
            >
              <div className="w-14 h-14 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white text-primary transition-colors duration-300">
                <service.icon className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 font-display">
                {service.title}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                {service.description}
              </p>
              <a href="#appointment" className="inline-flex items-center text-sm font-semibold text-primary group-hover:text-primary-dark transition-colors">
                Learn More <span className="ml-1 group-hover:translate-x-1 transition-transform">→</span>
              </a>
            </motion.div>
          ))}
        </div>

        {preview && (
          <div className="mt-16 text-center">
            <Link to="/services" className="inline-flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-8 py-4 rounded-xl font-medium transition-all shadow-xl hover:-translate-y-1 text-lg">
              View All Services
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
// Using LayoutGrid temporarily and importing it
