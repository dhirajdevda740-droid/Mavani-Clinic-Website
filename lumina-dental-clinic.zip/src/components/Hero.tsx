import { motion } from 'motion/react';
import { ChevronRight, Star, ShieldCheck, HeartPulse, Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[100svh] flex items-center pt-24 pb-16 overflow-hidden hero-gradient">
      {/* Background aesthetics */}
      <div className="absolute top-0 right-0 w-full md:w-1/2 h-full bg-gradient-to-bl from-primary/5 via-transparent to-transparent pointer-events-none" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute top-40 -left-20 w-72 h-72 bg-secondary/10 rounded-full blur-[80px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex flex-col items-start"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white shadow-sm border border-slate-100 mb-6 group cursor-default">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary"></span>
              </span>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-600">Accepting New Patients</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold leading-[1.1] tracking-tight text-slate-900 mb-6">
              Crafting Confident <span className="text-gradient">Smiles</span> with Advanced Dental Care
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 mb-8 max-w-xl font-sans leading-relaxed">
              Experience the pinnacle of oral health at Lumina Dental Studio. Precision, luxury, and care wrapped into one painless experience.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <a
                href="#appointment"
                className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-xl font-medium transition-all shadow-xl shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-1 text-lg group"
              >
                Book Appointment
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="tel:+919876543210"
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-slate-50 text-slate-800 px-8 py-4 rounded-xl font-medium transition-all shadow-md shadow-slate-200/50 border border-slate-100 hover:-translate-y-1 text-lg"
              >
                Call Now
              </a>
            </div>

            <div className="mt-10 flex items-center gap-4">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <img
                    key={i}
                    src={`https://ui-avatars.com/api/?name=Patient+${i}&background=random&color=fff&size=64`}
                    alt="Happy patient"
                    className="w-12 h-12 rounded-full border-2 border-white shadow-sm"
                    loading="lazy"
                  />
                ))}
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1 text-amber-500">
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                </div>
                <p className="text-sm font-medium text-slate-700">1000+ Happy Patients</p>
              </div>
            </div>
          </motion.div>

          {/* Image & Floating Cards */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="relative lg:h-[600px] flex justify-center lg:justify-end items-center"
          >
            {/* Main Image Container */}
            <div className="relative w-full max-w-md aspect-[4/5] rounded-[2rem] overflow-hidden shadow-2xl shadow-slate-300/50 isolate">
              <div className="absolute inset-0 bg-primary/10 mix-blend-multiply z-10" />
              <img
                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                alt="Modern dental clinic"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Floating Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="absolute -left-6 lg:-left-20 top-20 glass p-4 rounded-2xl flex items-center gap-4 shadow-xl z-20"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-primary flex items-center justify-center shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium leading-tight">Advanced</p>
                <p className="text-slate-900 font-bold leading-tight">Technology</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="absolute -right-6 lg:-right-8 bottom-32 glass p-4 rounded-2xl flex items-center gap-4 shadow-xl z-20"
            >
              <div className="w-12 h-12 rounded-xl bg-teal-100 text-secondary flex items-center justify-center shrink-0">
                <HeartPulse className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium leading-tight">Painless</p>
                <p className="text-slate-900 font-bold leading-tight">Procedures</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.0 }}
              className="absolute bottom-6 left-10 lg:left-0 glass p-4 rounded-2xl flex items-center gap-4 shadow-xl z-20"
            >
              <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium leading-tight">Multi-speciality</p>
                <p className="text-slate-900 font-bold leading-tight">Care</p>
              </div>
            </motion.div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
