import { motion } from 'motion/react';
import React, { useState, useEffect } from 'react';
import { Menu, X, PhoneCall, Calendar } from 'lucide-react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/#about' },
    { name: 'Services', href: '/services' },
    { name: 'Our Doctors', href: '/#doctor' },
    { name: 'Blog', href: '/#blog' },
    { name: 'Contact', href: '/#contact' },
  ];

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'glass py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white shadow-lg group-hover:shadow-primary/30 transition-all">
              <span className="font-display font-bold text-xl tracking-tighter">L</span>
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-lg leading-none text-slate-900 group-hover:text-primary transition-colors">LUMINA</span>
              <span className="text-[10px] uppercase tracking-widest text-primary font-semibold font-sans">Dental Studio</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-slate-600 hover:text-primary transition-colors relative after:absolute after:bottom-0 after:left-0 after:h-[2px] after:w-0 after:bg-primary after:transition-all hover:after:w-full"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <a href="tel:+919876543210" className="flex items-center gap-2 text-sm font-medium text-slate-700 hover:text-primary transition-colors">
              <PhoneCall className="w-4 h-4" />
              <span>+91 98765 43210</span>
            </a>
            <a
              href="#appointment"
              className="bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-full text-sm font-medium transition-all shadow-lg shadow-primary/30 hover:shadow-primary/40 flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              Book Consultation
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-slate-600 hover:text-primary transition-colors cursor-pointer"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden glass border-t border-white/20 mt-3"
        >
          <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-base font-medium text-slate-700 hover:text-primary block py-2 border-b border-slate-100/50"
              >
                {link.name}
              </a>
            ))}
            <div className="flex flex-col gap-3 mt-2">
              <a href="tel:+919876543210" className="flex items-center justify-center gap-2 text-sm font-medium text-slate-700 glass py-3 rounded-xl">
                <PhoneCall className="w-4 h-4 text-primary" />
                <span>+91 98765 43210</span>
              </a>
              <a
                href="#appointment"
                onClick={() => setIsMobileMenuOpen(false)}
                className="bg-primary text-white py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 shadow-lg shadow-primary/30"
              >
                <Calendar className="w-4 h-4" />
                Book Consultation
              </a>
            </div>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
}
