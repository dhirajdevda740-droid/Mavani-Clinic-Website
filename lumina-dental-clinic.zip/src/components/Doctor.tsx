import { motion } from 'motion/react';
import { Award, GraduationCap, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef } from 'react';

export default function Doctor() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  const doctors = [
    {
      name: "Dr. Sarah Mitchell",
      role: "Lead Orthodontist",
      qualifications: "DDS, MS (Orthodontics)",
      description: "As the principal dentist and orthodontist at Lumina Dental Studio, Dr. Sarah Mitchell is dedicated to transforming smiles and improving lives. With over a decade of hands-on experience, she ensures every patient receives meticulous treatment tailored to their needs.",
      description2: "Her approach combines a warm, friendly demeanor with the latest evidence-based clinical techniques, guaranteeing a relaxing and highly effective dental experience for patients of all ages.",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      experience: "12+",
      cases: "5k+",
      rating: "4.9"
    },
    {
      name: "Dr. James Wilson",
      role: "Cosmetic Dentist",
      qualifications: "DDS, FAGD",
      description: "Dr. Wilson brings a gentle touch and an artistic eye to every cosmetic and restorative procedure. He specializes in advanced smile designing, ensuring each patient achieves their dream aesthetic seamlessly.",
      description2: "His dedication to patient comfort and hygiene makes even the most complex dental procedures feel completely straightforward and anxiety-free.",
      image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      experience: "10+",
      cases: "3k+",
      rating: "4.8"
    },
    {
      name: "Dr. Emily Chen",
      role: "Endodontist",
      qualifications: "DDS, MS (Endodontics)",
      description: "Specializing in painless root canal treatments, Dr. Chen utilizes advanced dental technology and microscopy to expertly save teeth that would otherwise be permanently lost.",
      description2: "Her precise, calculated approach minimizes discomfort while maximizing the health and longevity of your natural teeth.",
      image: "https://images.unsplash.com/photo-1594824436998-058b29ff63a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      experience: "8+",
      cases: "6k+",
      rating: "5.0"
    }
  ];

  return (
    <section id="doctor" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex justify-between items-end mb-10">
          <div>
            <div className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-primary font-semibold text-sm mb-4 border border-blue-100">
              Our Experts
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900">
              Meet Our <span className="text-primary">Specialists</span>
            </h2>
          </div>
          <div className="hidden md:flex gap-3">
            <button 
              onClick={() => scroll('left')}
              className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-primary hover:text-white hover:border-primary transition-all shadow-sm"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button 
              onClick={() => scroll('right')}
              className="w-12 h-12 rounded-full border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-primary hover:text-white hover:border-primary transition-all shadow-sm"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="relative">
          <div 
            ref={scrollRef}
            className="flex overflow-x-auto snap-x snap-mandatory hide-scrollbar gap-6 pb-8"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {doctors.map((doctor, index) => (
              <div 
                key={index} 
                className="w-full shrink-0 snap-center"
              >
                <div className="bg-slate-50 rounded-[3rem] p-8 md:p-12 lg:p-16 border border-slate-100 shadow-sm relative overflow-hidden h-full">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px]" />
                  
                  <div className={`grid grid-cols-1 ${doctor.image ? 'lg:grid-cols-2' : ''} gap-12 items-center relative z-10`}>
                    {/* Image */}
                    {doctor.image && (
                      <div className="relative mx-auto lg:mx-0 w-full max-w-md">
                        <div className="aspect-[3/4] rounded-3xl overflow-hidden border-8 border-white shadow-2xl relative">
                          <img
                            src={doctor.image}
                            alt={doctor.name}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent" />
                        </div>
                        
                        <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-xl border border-slate-50 flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-primary">
                            <Star className="w-6 h-6 fill-current" />
                          </div>
                          <div>
                            <p className="text-xl font-bold text-slate-900">{doctor.rating}/5</p>
                            <p className="text-xs text-slate-500 font-medium tracking-wide uppercase">Patient Rating</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Content */}
                    <div className={!doctor.image ? "max-w-3xl mx-auto text-center" : ""}>
                      <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white shadow-sm border border-slate-100 mb-6 ${!doctor.image ? 'justify-center' : ''}`}>
                        <Award className="w-4 h-4 text-primary" />
                        <span className="text-sm font-semibold text-slate-700">{doctor.role}</span>
                      </div>
                      
                      <h3 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-2">
                        {doctor.name}
                      </h3>
                      <h4 className={`text-xl text-primary font-medium mb-6 flex items-center gap-2 ${!doctor.image ? 'justify-center' : ''}`}>
                        <GraduationCap className="w-5 h-5" />
                        {doctor.qualifications}
                      </h4>
                      
                      <p className="text-lg text-slate-600 mb-6 font-sans leading-relaxed">
                        {doctor.description}
                      </p>
                      
                      <p className="text-lg text-slate-600 mb-10 font-sans leading-relaxed">
                        {doctor.description2}
                      </p>
                      
                      <div className={`grid grid-cols-2 gap-4 ${!doctor.image ? 'max-w-md mx-auto' : ''}`}>
                        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                          <p className="text-3xl font-display font-bold text-slate-900 mb-1">{doctor.experience}</p>
                          <p className="text-sm text-slate-500 font-medium">Years Experience</p>
                        </div>
                        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
                          <p className="text-3xl font-display font-bold text-slate-900 mb-1">{doctor.cases}</p>
                          <p className="text-sm text-slate-500 font-medium">Smiles Restored</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
