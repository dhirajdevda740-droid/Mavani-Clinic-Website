import { motion } from 'motion/react';
import { Calendar, PhoneCall, Send } from 'lucide-react';
import React from 'react';

export default function Appointment() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you! Your appointment request has been submitted. We will contact you shortly.");
  };

  return (
    <section id="appointment" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[3rem] overflow-hidden shadow-2xl relative">
          
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-secondary/20 rounded-full blur-[120px] pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-5 relative z-10">
            
            {/* Left Content */}
            <div className="lg:col-span-2 p-10 md:p-14 text-white flex flex-col justify-center border-r border-white/10">
              <h2 className="text-4xl lg:text-5xl font-display font-bold mb-6">
                Book Your Smile Consultation
              </h2>
              <p className="text-slate-300 text-lg mb-10 leading-relaxed">
                Take the first step towards a healthier, brighter smile. Fill out the form, and our team will get back to you promptly to confirm your slot.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                    <PhoneCall className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Call us immediately</p>
                    <a href="tel:+919876543210" className="text-xl font-bold hover:text-primary transition-colors">+91 98765 43210</a>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-400">Clinic Timings</p>
                    <p className="text-lg font-medium">Mon-Sat: 9 AM - 8 PM</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="lg:col-span-3 p-10 md:p-14 bg-white/5 backdrop-blur-sm">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Full Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all placeholder:text-slate-500"
                      placeholder="John Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Phone Number</label>
                    <input 
                      required
                      type="tel" 
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all placeholder:text-slate-500"
                      placeholder="+91 90000 00000"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Treatment Type</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all appearance-none [&>option]:text-slate-900">
                      <option value="">Select Treatment</option>
                      <option value="consultation">General Consultation</option>
                      <option value="braces">Braces / Aligners</option>
                      <option value="implants">Dental Implants</option>
                      <option value="root-canal">Root Canal</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Preferred Date</label>
                    <input 
                      type="date" 
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all [&::-webkit-calendar-picker-indicator]:filter [&::-webkit-calendar-picker-indicator]:invert"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300">Message (Optional)</label>
                  <textarea 
                    rows={4}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all placeholder:text-slate-500 resize-none"
                    placeholder="Tell us about your dental concerns..."
                  ></textarea>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-primary hover:bg-primary-dark text-white rounded-xl px-6 py-4 font-bold text-lg flex items-center justify-center gap-2 transition-colors shadow-lg shadow-primary/20"
                >
                  Confirm Appointment
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
}
