import { motion } from 'motion/react';
import { ArrowRight, Clock, User } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function BlogPreview() {
  return (
    <section id="blog" className="py-24 bg-background-soft border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6 md:gap-0">
          <div className="max-w-2xl">
            <div className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-primary font-semibold text-sm mb-4 border border-blue-100">
              Latest Insights
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-6">
              Dental <span className="text-primary">Journal</span>
            </h2>
          </div>
          <div className="hidden md:block">
            <Link to="/blog/turkey-teeth-trend" className="inline-flex items-center text-primary font-semibold hover:text-primary-dark transition-colors gap-2">
              All Articles <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>

        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           transition={{ duration: 0.5 }}
           className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-xl transition-all duration-300 card-shadow group"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative h-64 lg:h-auto overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                alt="Dental Veneers" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-slate-800 uppercase tracking-wider shadow-sm">
                Trending
              </div>
            </div>
            <div className="p-8 md:p-12 flex flex-col justify-center">
              <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> 5 min read</span>
                <span className="flex items-center gap-1"><User className="w-4 h-4" /> Dr. Sarah Mitchell</span>
              </div>
              <h3 className="text-3xl font-display font-bold text-slate-900 mb-4 group-hover:text-primary transition-colors leading-tight">
                The Truth About the Viral "Turkey Teeth" Trend
              </h3>
              <p className="text-slate-600 mb-8 leading-relaxed line-clamp-3 text-justify">
                Social media is full of influencers flaunting their bright white "Turkey Teeth", but what are the hidden risks of this extreme dental tourism trend? We break down the difference between veneers and aggressive crown preps, and why preserving your natural enamel is vital for long-term oral health.
              </p>
              <Link to="/blog/turkey-teeth-trend" className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-medium transition-all w-fit group-hover:bg-primary shadow-md">
                Read Full Article <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </motion.div>
        
        <div className="mt-8 md:hidden text-center">
            <Link to="/blog/turkey-teeth-trend" className="inline-flex items-center text-primary font-semibold hover:text-primary-dark transition-colors gap-2">
              All Articles <ArrowRight className="w-5 h-5" />
            </Link>
        </div>
      </div>
    </section>
  );
}
