import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

export default function Testimonials() {
  const reviews = [
    {
      name: "Michael Roberts",
      text: "Dr. Mitchell is incredible! The braces treatment was entirely painless and highly professional. The clinic is absolutely beautiful and clean.",
      rating: 5,
      image: "https://ui-avatars.com/api/?name=Michael+Roberts&background=0ea5e9&color=fff"
    },
    {
      name: "Emily Clark",
      text: "I was always scared of dentists, but the root canal here was a breeze. They explained everything clearly and made me feel completely at ease.",
      rating: 5,
      image: "https://ui-avatars.com/api/?name=Emily+Clark&background=0f766e&color=fff"
    },
    {
      name: "David Chen",
      text: "Got invisible aligners from this clinic. The results are amazing and the process was so smooth. Highly recommend for any orthodontic needs.",
      rating: 5,
      image: "https://ui-avatars.com/api/?name=David+Chen&background=slate&color=fff"
    }
  ];

  return (
    <section className="py-24 bg-background-soft">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-primary font-semibold text-sm mb-4 border border-blue-100">
            Patient Stories
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-6">
            Loved by <span className="text-primary">Our Patients</span>
          </h2>
          <p className="text-lg text-slate-600">
            Don't just take our word for it. Hear what our happy patients have to say about their experience with us.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white p-8 rounded-3xl card-shadow border border-slate-100 relative group transition-all duration-300 transform hover:-translate-y-1"
            >
              <Quote className="absolute top-6 right-8 w-12 h-12 text-slate-100 group-hover:text-primary/10 transition-colors" />
              
              <div className="flex items-center gap-1 text-amber-500 mb-6">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" />
                ))}
              </div>
              
              <p className="text-slate-700 text-lg mb-8 leading-relaxed relative z-10">
                "{review.text}"
              </p>
              
              <div className="flex items-center gap-4 mt-auto">
                <img src={review.image} alt={review.name} className="w-12 h-12 rounded-full" />
                <div>
                  <h4 className="font-bold text-slate-900 font-display">{review.name}</h4>
                  <p className="text-sm text-slate-500">Verified Patient</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
