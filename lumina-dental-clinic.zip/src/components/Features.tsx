import { motion } from 'motion/react';
import { 
  Award, ShieldCheck, Clock, Heart, 
  ThumbsUp, Wallet, Coffee, Microscope 
} from 'lucide-react';

export default function Features() {
  const features = [
    { title: "Experienced Specialists", icon: Award },
    { title: "Advanced Technology", icon: Microscope },
    { title: "Hygienic Sterilization", icon: ShieldCheck },
    { title: "Painless Procedures", icon: ThumbsUp },
    { title: "Personalized Care", icon: Heart },
    { title: "Affordable Treatments", icon: Wallet },
    { title: "Comfortable Environment", icon: Coffee },
    { title: "Transparent Consultation", icon: Clock },
  ];

  return (
    <section className="py-24 bg-primary relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 opacity-10">
        <svg className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M0 40L40 0H20L0 20M40 40V20L20 40" fill="transparent" stroke="white" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid-pattern)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-6">
            Why Choose Us?
          </h2>
          <p className="text-lg text-blue-100">
            We prioritize your comfort and health above all, delivering exceptional results with the highest standards of safety.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="glass p-6 rounded-2xl flex flex-col items-center text-center group hover:bg-white transition-colors"
            >
              <feature.icon className="w-10 h-10 text-primary mb-4 transition-colors" />
              <h3 className="text-slate-800 font-semibold group-hover:text-primary transition-colors">
                {feature.title}
              </h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
