import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export default function About() {
  const points = [
    "Personalized dental care tailored to you",
    "Comfortable, stress-free treatment experience",
    "State-of-the-art modern dental technology",
    "Orthodontic expertise for perfect alignment",
    "Patient-first approach in every consultation"
  ];

  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Images Grid */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-4 relative z-10 w-full max-w-[500px] mx-auto lg:mx-0">
              <motion.img
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Clinic Interior"
                className="rounded-3xl w-full h-64 object-cover mt-8 shadow-xl"
              />
              <motion.img
                initial={{ opacity: 0, y: -20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Doctor Consultation"
                className="rounded-3xl w-full h-64 object-cover shadow-xl"
              />
              
              {/* Experience Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white p-4 rounded-2xl shadow-2xl flex flex-col items-center justify-center min-w-[120px] z-20 border border-slate-50"
              >
                <div className="text-4xl font-display font-bold text-primary mb-1">10+</div>
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 text-center">Years of<br/>Excellence</div>
              </motion.div>
            </div>
            
            <div className="absolute -inset-4 bg-gradient-to-r from-primary/10 to-transparent rounded-[3rem] -z-10 blur-2xl" />
          </div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-block px-4 py-1.5 rounded-full bg-blue-50 text-primary font-semibold text-sm mb-6 border border-blue-100">
              About Our Clinic
            </div>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-6 leading-tight">
              Redefining <span className="text-primary">Dental Care</span>
            </h2>
            <p className="text-lg text-slate-600 mb-8 font-sans leading-relaxed">
              At Lumina Dental Studio, we merge luxury with healthcare. Our mission is to provide world-class dental treatments in a serene, anxiety-free environment. Your smile is our signature.
            </p>

            <ul className="space-y-4 mb-10">
              {points.map((point, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="flex items-center gap-3 text-slate-700 font-medium"
                >
                  <CheckCircle2 className="w-6 h-6 text-secondary shrink-0" />
                  <span>{point}</span>
                </motion.li>
              ))}
            </ul>

            <a
              href="#doctor"
              className="inline-flex items-center justify-center bg-slate-900 hover:bg-slate-800 text-white px-8 py-4 rounded-xl font-medium transition-all shadow-lg hover:-translate-y-1 text-lg"
            >
              Meet Our Specialists
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
